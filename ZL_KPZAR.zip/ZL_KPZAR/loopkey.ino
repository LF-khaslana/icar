void loop_key(void) {
    static u32 press_time_up = 0;
    static u32 press_time_down = 0;
    static bool long_press_active_up = false;
    static bool long_press_active_down = false;

    // 检测按键上
    if(PS2_P_LEFT_UP) {
        if(press_time_up == 0) {
            press_time_up = millis();
        }
        
        // 长按处理（只执行一次）
        if(!long_press_active_up && (millis() - press_time_up >= 500)) {
            long_press_active_up = true;
            // 长按执行代码
        }
    } 
    else if(press_time_up > 0) {
        // 短按处理
        if(!long_press_active_up && (millis() - press_time_up < 500)) {
            motor1_speed+=10;
            if(motor1_speed>1000) motor1_speed=1000;
            motor1_SetSpeed(motor1_speed);
            
            motor2_speed+=10;
            if(motor2_speed>1000) motor2_speed=1000;
            motor2_SetSpeed(motor2_speed);
        }
        
        // 重置状态
        press_time_up = 0;
        long_press_active_up = false;
    }

    // 检测按键下（同理）
    if(PS2_P_LEFT_DOWN) {
        if(press_time_down == 0) {
            press_time_down = millis();
        }
        
        if(!long_press_active_down && (millis() - press_time_down >= 500)) {
            long_press_active_down = true;
            // 长按执行代码
        }
    } 
    else if(press_time_down > 0) {
        if(!long_press_active_down && (millis() - press_time_down < 500)) {
            motor1_speed-=10;
            if(motor1_speed<-1000) motor1_speed=-1000;
            motor1_SetSpeed(motor1_speed);
            
            motor2_speed-=10;
            if(motor2_speed<-1000) motor2_speed=-1000;
            motor2_SetSpeed(motor2_speed);
        }
        
        press_time_down = 0;
        long_press_active_down = false;
    }
}