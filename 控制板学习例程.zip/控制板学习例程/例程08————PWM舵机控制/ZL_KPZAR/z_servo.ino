/****************************************************************************
	*	@笔者	：	W
	*	@日期	：	2019年12月28日
	*	@所属	：	杭州众灵科技
	*	@论坛	：	www.ZL-robot.com
	*	@功能	：	存放舵机相关的函数
	*	@函数列表：
	*	1.	void led_init(void) -- 初始化LED信号灯
	*	2.	void LED_F(void) -- 翻转LED信号灯
 ****************************************************************************/

/***********************************************
	函数名称:		servo_init() 
	功能介绍:		初始化舵机
	函数参数:		无
	返回值:			无
 ***********************************************/
void servo_init(void) {
	for(byte i = 0; i < SERVO_NUM; i ++) {
		myservo[i].attach(servo_pin[i]);
		myservo[i].writeMicroseconds(servo_data[i].aim);
	}
}

/***********************************************
	函数名称:		servo_run(index,aim,time) 
	功能介绍:		舵机控制函数
	函数参数:		index 舵机编号 aim 目标值 time 时间量
	返回值:			无
 ***********************************************/
void servo_run(u8 index, int aim, int time) {
	if(index < SERVO_NUM && (aim<=2500)&& (aim>=500) && (time<10000)) {
		if(servo_data[index].cur == aim){
			aim = aim+0.0077;
		}
		
		if(aim>2497)	aim=2497;
		if(aim<500)		aim=500;
		
		if(time < 20) {
			servo_data[index].aim = aim;
			servo_data[index].cur = aim;
			servo_data[index].inc = 0;
		} else {
			servo_data[index].aim = aim;
			servo_data[index].time = time;
			servo_data[index].inc = (servo_data[index].aim-servo_data[index].cur)/(servo_data[index].time/20.000);
		}
	}
}