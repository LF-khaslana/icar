/****************************************************************************
	*	@笔者	：	W
	*	@日期	：	2019年12月28日
	*	@所属	：	杭州众灵科技
	*	@论坛	：	www.ZL-robot.com
	*	@功能	：	ZL-KPZ控制板（AR版）模块例程8————PWM舵机控制
	*	@函数列表：
	*	1.	void setup(void) -- 初始化函数
	*	2.	void loop(void) -- 主循环函数
 ****************************************************************************/

#include <Servo.h>			//声明调用Servo.h库

/*******全局变量宏定义*******/
#define SERVO_NUM 8

/*******结构体定义*******/
typedef struct {
	float aim;
	float cur;
	float inc;
	int time;
}servo_data_t;

/*******全局变量定义*******/
u8 i=0;
servo_data_t servo_data[SERVO_NUM];
u8 servo_index;
byte  servo_pin[SERVO_NUM] = {7, 3, 5, 6, 9 ,8};	//宏定义舵机控制引脚
Servo myservo[SERVO_NUM];	//创建一个舵机类

void setup(void) {																																																																																																																															//ZL
	setup_key();			//初始化按键
	setup_servo();			//初始化舵机相关设置
}
void loop(void) {
	loop_key();				//循环检测按键状态
	loop_servo();			//循环处理舵机的指令
}
